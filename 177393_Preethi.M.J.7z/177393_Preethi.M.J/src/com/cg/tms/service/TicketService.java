package com.cg.tms.service;

import java.util.List;
import java.util.Map;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;

public interface TicketService {
boolean raiseNewTicket(TicketBean ticketBean);
Map<String,String> listTicketCategoty();
public  String addDetails(String ticketno,TicketBean t);
public List<TicketCategory> listTicketCategory1();

}
