package com.cg.tms.service;

import java.util.List;
import java.util.Map;

import com.cg.tms.dao.TicketDAO;
import com.cg.tms.dao.TicketDAOImpl;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.util.Util;

public class TicketServiceImpl implements TicketService{
	TicketDAO ticketDao=new TicketDAOImpl();

	@Override
	public boolean raiseNewTicket(TicketBean ticketBean) {
		boolean result=ticketDao.raiseNewTicket(ticketBean);
		return result;
	}

	@Override
	public  Map<String,String> listTicketCategoty() {
		 Map<String,String> map=	ticketDao.listTicketCategoty();
		return map;
	}
	public  String addDetails(String ticketno,TicketBean t)
	{
		ticketDao.addDetails(ticketno, t);
		return t.getTicketNo();
	}
	public List<TicketCategory> listTicketCategory1()
	{
		List<TicketCategory> t=	ticketDao.listTicketCategory1();
		return t;
		
	}
	
	
	}


