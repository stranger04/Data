package com.cg.tms.ticketException;

public class TicketException extends Exception{

	public TicketException(String arg0) {
		super(arg0);
		
	}

}
