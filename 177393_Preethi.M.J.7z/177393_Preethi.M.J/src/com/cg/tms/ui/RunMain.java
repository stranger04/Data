package com.cg.tms.ui;

import java.time.LocalDate;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.service.TicketService;
import com.cg.tms.service.TicketServiceImpl;
import com.cg.tms.ticketException.TicketException;

public class RunMain {

	static Scanner sc=null;
	static TicketService ticketService=null;
	public static void main(String[] args)  throws TicketException{
		
		sc=new Scanner(System.in);
		ticketService=new TicketServiceImpl();
		System.out.println("Welcome to ITIMD Help Desk");
		System.out.println("enter the choice");
		System.out.println("Press 1. To raise a Ticket");
		System.out.println("Press 2. Exit from the system");
		int choice=sc.nextInt();
		
	switch(choice)
	{
		
	case 1: raiseTicket();
	
		break;
	case 2: System.exit(0);
	break;
		default:
	}
	}
	
	
	
	public static void raiseTicket()
	{
		try
		{
			
		
		System.out.println("select Ticket category from the below list:");
	     
		List<TicketCategory> l=ticketService.listTicketCategory1();
		for(int i=0;i<l.size();i++)
		{
	System.out.println(l.get(i));
	
		}
		  System.out.println("enter option");
		  int ticketCategoryId=sc.nextInt();
		 
		  Map<String,String> map= ticketService.listTicketCategoty();
		  switch(ticketCategoryId)
		  {
		  case 1:  System.out.println(map.get("tc001"));	
		           break;
		  case 2:System.out.println(map.get("tc002")); 
		         break;
		  case 3:System.out.println(map.get("tc003"));  
		         break;
		  case 4:System.out.println("invalid");   
		          break;
		     default: System.exit(0);
		  }
		
	
	int ticketNo=(int )(Math. random() * 5000 + 1);
	System.out.println("enter description related to issue");
	String ticketDescription=sc.next();

	System.out.print("enter the priority:");
	System.out.print("1.low"+"  "+"2.medium"+" "+"3.high");
	
int ticketPriority=sc.nextInt();
	switch(ticketPriority)
	{
	case 1: System.out.println("low");;
	       break;
	case 2: System.out.println("medium");     
	       break;
	case 3:System.out.println("high");    
	   break;
	   default:System.out.println("invalid");
	   break;
	}
	System.out.println("enter the ticketStatus");
	String ticketStatus=sc.next();
	System.out.println("Any itimdComments");
	String itimdComments=sc.next();
	
	TicketBean ticketBean=new TicketBean(String.valueOf(ticketNo) , String.valueOf(ticketCategoryId), ticketDescription, String.valueOf(ticketPriority), ticketStatus, itimdComments);
	
	
	String ticketNoAdded=ticketService.addDetails(String.valueOf(ticketNo), ticketBean);

		Boolean result=	ticketService.raiseNewTicket(ticketBean);
		if(result==true)
		{
			System.out.println("Ticket details are added sucessfully");
			System.out.println("TicketNumber:"+String.valueOf(ticketNo)+"logged Successfully:" +LocalDate.now());

		}
		
	
	}catch(Exception e)
		{
		
		e.printStackTrace();
		}
	
	}
	
}
