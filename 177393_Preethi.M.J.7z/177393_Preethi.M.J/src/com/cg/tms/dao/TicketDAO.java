package com.cg.tms.dao;

import java.util.List;
import java.util.Map;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;

public interface TicketDAO {

	boolean raiseNewTicket(TicketBean ticketBean);
	 Map<String,String>  listTicketCategoty();
	 public String addDetails(String ticketno,TicketBean t);
	 public  List<TicketCategory> listTicketCategory1();
	 public String getValue(String choice);
}
