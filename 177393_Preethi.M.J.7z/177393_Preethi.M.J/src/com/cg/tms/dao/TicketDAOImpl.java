package com.cg.tms.dao;

import java.util.List;
import java.util.Map;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.util.Util;

public class TicketDAOImpl implements TicketDAO{

	@Override
	public boolean raiseNewTicket(TicketBean ticketBean) {
		
	boolean result=Util.raiseTicket(ticketBean);
		return result;
	}

	@Override
	public  Map<String,String> listTicketCategoty() {
		 Map<String,String> map=	 Util.getTicketCategoryEntries()	;
		return map;
	}
	public  String addDetails(String ticketno,TicketBean t)
	{
		Util.addDetails(ticketno, t);
		return t.getTicketNo();
	}
	public List<TicketCategory> listTicketCategory1()
	{
		List<TicketCategory> t=	Util.listTicketCategory1();
		return t;
		
	}
	public  String getValue(String choice)
	{
	return	Util.getValue(choice);
	}

}
