package com.cg.tms.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;

public class Util {
	private static HashMap<String,TicketBean> ticketBean=new HashMap<String,TicketBean>();
	private static Map<String,String>  ticketCategory=new HashMap<String,String>();
	public static Map<String,String> getTicketCategoryEntries()
	{
		ticketCategory.put("tc001", "software installation");
		ticketCategory.put("tc002", "mailbox creation");
		ticketCategory.put("tc003", "mailbox issues");
		return ticketCategory;
		
	}
	private static List<TicketCategory> ticket=new ArrayList<TicketCategory>();
	static
	{
		ticket.add(new TicketCategory ("tc001", "software installation"));
		ticket.add(new TicketCategory ("tc002", "mailbox creation"));
		ticket.add(new TicketCategory ("tc003", "mailbox issues"));
	}
	
	
public static boolean raiseTicket(TicketBean ticketBean)
{
	boolean result=ticketBean.equals(ticketBean);
	return result;
	
}
public static void addDetails(String ticketno,TicketBean t)
{
	ticketBean.put(ticketno, t);
	
}
public static List<TicketCategory> listTicketCategory1()
{
	return ticket;
	
}
public static String getValue(String choice)
{
	
	return ticketCategory.get(choice);
}
}