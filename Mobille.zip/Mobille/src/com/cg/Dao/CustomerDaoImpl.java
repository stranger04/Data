package com.cg.Dao;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import com.cg.entity.Customer;
import com.cg.entity.Mobile;
import com.cg.entity.MobileInfo;
import com.cg.util.CollectionUtil;

//connects dao and collectionutil0
public class CustomerDaoImpl implements CustomerDao {

	@Override
	public int purchaseModel(Customer c,Mobile m) {
		int c1=CollectionUtil.purchaseModel(c,m);
		return c1;
	}

	@Override
	public Mobile getPurchaseDetails(int orderId) {
		Mobile m3=CollectionUtil.getPurchaseDetails(orderId);
		return m3;
	}

	@Override
	public HashMap<String, MobileInfo> mobileDetails() {
		HashMap<String, MobileInfo> m1=CollectionUtil.mobileDetails();
		return m1;
	}
	public MobileInfo mobileModelDetails(String modelname){
		MobileInfo m1=CollectionUtil.mobileModelDetails(modelname);
		return m1;
		
	}

	@Override
	public Customer customerDetails(int customerid) {
		Customer c2=CollectionUtil.customerDetails(customerid);
		return c2;
	}

	@Override
	public List<MobileInfo> sortMobilebyName() {
		List<MobileInfo> e=CollectionUtil.SortByName();
		return e;
	}

	/*@Override
	public List<MobileInfo> sortMobilebyPrice() {
		List<MobileInfo> e1=CollectionUtil.sortbyPrice();
		return e1;
	}*/

}
