package com.cg.exception;

public class CustomerException extends Exception{

	public CustomerException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
