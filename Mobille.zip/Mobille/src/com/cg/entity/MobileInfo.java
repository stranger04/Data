package com.cg.entity;

import java.util.Comparator;


public class MobileInfo {
	private String modelname;
	private int totalpricewithGST;
	public MobileInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public MobileInfo(String modelname, int totalpricewithGST) {
		super();
		this.modelname = modelname;
		this.totalpricewithGST = totalpricewithGST;
	}
	public String getModelname() {
		return modelname;
	}
	public void setModelname(String modelname) {
		this.modelname = modelname;
	}
	public int getTotalpricewithGST() {
		return totalpricewithGST;
	}
	public void setTotalpricewithGST(int totalpricewithGST) {
		this.totalpricewithGST = totalpricewithGST;
	}
	@Override
	public String toString() {
		return "MobileInfo [modelname=" + modelname + ", totalpricewithGST="
				+ totalpricewithGST + "]";
	}
	

	public static Comparator<MobileInfo> getcompname()
	{
		Comparator<MobileInfo> comp=new Comparator<MobileInfo>() {
	@Override
	public int compare(MobileInfo o1, MobileInfo o2) {
		return o1.modelname.compareTo(o2.modelname);
	}
		};
		return comp;
	}
	/*public static Comparator<MobileInfo> getcompPrice() {
		Comparator<MobileInfo> comp1=new Comparator<MobileInfo>() {
			@Override
			public int compare(MobileInfo p1, MobileInfo p2) {
				return p1.totalpricewithGST.compareTo(p2.totalpricewithGST);
			}
				};
				return comp1;

	}*/
}



