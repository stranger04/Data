/*package com.cg.junit;

import static org.junit.Assert.*;

import org.junit.Test;

public class MobileTest extends MobileTestCase {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
*/