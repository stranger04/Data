package com.cg.lab1_3;

import java.util.List;

public class SBU {
private int sbucode;
private String sbuName;
private String sbuHead;
private List<Employee> emplist;
public int getSbucode() {
	return sbucode;
}
public void setSbucode(int sbucode) {
	this.sbucode = sbucode;
}
public String getSbuName() {
	return sbuName;
}
public void setSbuName(String sbuName) {
	this.sbuName = sbuName;
}
public String getSbuHead() {
	return sbuHead;
}
public void setSbuHead(String sbuHead) {
	this.sbuHead = sbuHead;
}
public List<Employee> getEmplist() {
	return emplist;
}
public void setEmplist(List<Employee> emplist) {
	this.emplist = emplist;
}
@Override
public String toString() {
	return "SBU [sbucode=" + sbucode + ", sbuName=" + sbuName + ", sbuHead=" + sbuHead + ", emplist=" + emplist + "]";
}

}
