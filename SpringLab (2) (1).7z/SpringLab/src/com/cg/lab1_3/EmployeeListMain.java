package com.cg.lab1_3;

import java.util.List;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.cg.lab1_1.Employee;

public class EmployeeListMain {
public static void main(String[] args) {
	Resource res=new ClassPathResource("emplistCollection.xml");
	BeanFactory f=new XmlBeanFactory(res);
	
	SBU s=(SBU) f.getBean("employee");
	System.out.println("subcode="+s.getSbucode());
	System.out.println("subHead="+s.getSbuHead());
	System.out.println("subName="+s.getSbuName());
	List l=s.getEmplist();
	System.out.println(l);
}
}
