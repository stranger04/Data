package com.cg.lab1_1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.lab1_1.Employee;

public class EmployeeMain {
	public static void main(String[] args) {
		

	ApplicationContext ctx=new ClassPathXmlApplicationContext("employee.xml");
	Employee employee=(Employee) ctx.getBean("employee");
	System.out.println("Employee Id:"+employee.getEmpId());
	System.out.println("Employee Name:"+employee.getEmpName());
	System.out.println("Employe Age:"+employee.getAge());
	System.out.println("Employee Salary:"+employee.getEmpSalary());
	System.out.println("Employee Bussiness Unit:"+employee.getBusinessUnit());
	}
}
