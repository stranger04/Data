package com.cg.lab1_2;

public class Employee {
	private String empName;
	private int empId;
	private double empSalary;
	private SBU businessUnit;

	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public double getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}
	public SBU getBusinessUnit() {
		return businessUnit;
	}
	public void setBusinessUnit(SBU businessUnit) {
		this.businessUnit = businessUnit;
	}
	@Override
	public String toString() {
		return "Employee [empName=" + empName + ", empId=" + empId + ", empSalary=" + empSalary + ", businessUnit="
				+ businessUnit + "]";
	}
	public SBU getSbuDetails() {
		SBU bu=new SBU(101,"MODI","IT SERVICES");
		return bu;
	}
	
	
}
