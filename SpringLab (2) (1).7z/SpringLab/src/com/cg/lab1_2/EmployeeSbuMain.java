package com.cg.lab1_2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;


import com.cg.lab1_2.Employee;

public class EmployeeSbuMain {
	public static void main(String[] args) {
		ApplicationContext ctx=new AnnotationConfigApplicationContext(EmployeeSbuConfig.class);
		Employee emp=(Employee) ctx.getBean("emp");
		System.out.println(emp);
	}

}
