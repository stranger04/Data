package com.cg.lab1_2;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class EmployeeSbuConfig {

	
@Bean
public Employee emp() {
	Employee emp=new Employee();
	emp.setEmpId(12345);
	emp.setEmpName("sowjanya");
	emp.setEmpSalary(50000);
SBU s=emp.getSbuDetails();
emp.setBusinessUnit(s);
	return emp;
}
}
