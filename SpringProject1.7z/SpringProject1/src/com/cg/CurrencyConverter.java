package com.cg;

public interface CurrencyConverter {
public double dollarToRupees(double dollars);

}
