package com.cg;

public class CurrencyConverterImpl implements CurrencyConverter {

	
	private ExchangeService exchangeService;

	public CurrencyConverterImpl() {
		System.out.println(" CurrencyConverterImpl()");
	
	}

	
	public ExchangeService getExchangeService() {
		System.out.println("getExchangeService()");
		return exchangeService;
	}

	public void setExchangeService(ExchangeService exchangeService) {
		System.out.println("setExchangeService()");
		this.exchangeService = exchangeService;
	}

	@Override
	public double dollarToRupees(double dollars) {
	System.out.println("dollarToRupees()");
		return dollars*exchangeService.getExchangeRate();
	}

	
/*public double exchangeRate;*/
	/*public double getExchangeRate() {
	return exchangeRate;
}



public void setExchangeRate(double exchangeRate) {
	this.exchangeRate = exchangeRate;
}



	public CurrenctConverterImpl(double exchangeRate) {
	super();
	this.exchangeRate = exchangeRate;
}



	@Override
	public double dollarToRupees(double dollars) {
		// TODO Auto-generated method stub
		return dollars*exchangeRate;
	}*/

}
