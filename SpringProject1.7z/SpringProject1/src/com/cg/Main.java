package com.cg;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Main {
public static void main(String[] args) {
	Resource res=new ClassPathResource("CurrencyConverter.xml");
	BeanFactory factory= new XmlBeanFactory(res);
	CurrencyConverter curr = (CurrencyConverter) factory.getBean("CurrConverter");
	double result =curr.dollarToRupees(55);
	System.out.println("55 $ into rupees is "+ result);
	
}
}
