package com.igate;

import java.util.List;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.cg.CurrencyConverter;

public class CurrencyListClient {

	
	
	public static void main(String[] args) {
		Resource res = new ClassPathResource("Collection.xml");
		BeanFactory factory= new XmlBeanFactory(res);
		CurrencyList curr = (CurrencyList) factory.getBean("CurrConverter1");
		List curs=curr.getcurrList();
		System.out.println(curs);
	}
}
