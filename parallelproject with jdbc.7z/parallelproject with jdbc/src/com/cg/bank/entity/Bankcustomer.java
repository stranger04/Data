package com.cg.bank.entity;

public class Bankcustomer {
	private String customername;
	private String mobileno;
	private String branch;
	private double balance;
	public String getCustomername() {
		return customername;
	}
	public void setCustomername(String customername) {
		this.customername = customername;
	}
	public String getMobileno() {
		return mobileno;
	}
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	public String getbranch() {
		return branch;
	}
	public void setbranch(String Branch) {
		branch = Branch;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Bankcustomer [customername=" + customername + ", mobileno="
				+ mobileno + ", branch=" + branch + ", balance=" + balance + "]";
	}
	public Bankcustomer(String customername, String mobileno, String Branch,
			double balance) {
		super();
		this.customername = customername;
		this.mobileno = mobileno;
		branch = Branch;
		this.balance = balance;
	}
	public Bankcustomer() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
