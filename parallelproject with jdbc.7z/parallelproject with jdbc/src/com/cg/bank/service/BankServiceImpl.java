package com.cg.bank.service;

import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.bank.dao.BankDAO;
import com.cg.bank.dao.BankDAOImpl;
import com.cg.bank.entity.Bankcustomer;
import com.cg.bank.excp.BankException;



public class BankServiceImpl implements BankService {
	BankDAO bd=new BankDAOImpl();

	@Override
	public int createaccount(Integer a, Bankcustomer b) throws ClassNotFoundException, SQLException {
		bd.createaccount(a, b);
		return 0;
	}

	@Override
	public Bankcustomer getbalance(int accno) throws ClassNotFoundException, SQLException {
		Bankcustomer bc=bd.getbalance(accno);
		return bc;
		
	}

	@Override
	public Bankcustomer deposit(int accno,double bal) throws SQLException, ClassNotFoundException {
		Bankcustomer bc=bd.deposit(accno,bal);
		return bc;
		
	}

	@Override
	public Bankcustomer withdraw(int accno,double bal) throws ClassNotFoundException, SQLException {
		Bankcustomer bc=bd.withdraw(accno,bal);
		return bc;
	}

	@Override
	public boolean validateCusName(String name) throws BankException {
		Pattern  pattern =Pattern.compile("[A-Z]{1}[a-z]{3,15}");
		Matcher idMatch= pattern.matcher(name);
		if(idMatch.matches())
		{
			return true;
		}
	
		return false;
	}

	
	@Override
	public boolean validateMobileNo(String cellno) throws BankException {
		Pattern pattern =Pattern.compile("[0-9]{10}");
		Matcher mobMatch= pattern.matcher(cellno);
		if(mobMatch.matches())
		{
			return true;
		}
		
		
		return false;
	}
	
}


	

