package com.cg.ac.service;

import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.cg.ac.bean.Account;
import com.cg.ac.dao.AccountDao;
import com.cg.ac.dao.AccountDaoImpl;
import com.cg.ac.exception.AccountException;

public class AccountServiceImpl implements AccountService {
	AccountDao acdao= new AccountDaoImpl();

	@Override
	public String createAccount(Account account) throws  ClassNotFoundException, SQLException {
		acdao.createAccount(account);
		return account.getContactNo();
	}

	@Override
	public Account showBalance(String accountNo) throws AccountException {
		Account account=acdao.showBalance(accountNo);
		return account;
	}



	
	public boolean validateName(String name) throws AccountException {
		Pattern p=Pattern.compile("[a-zA-Z]{2,12}");
		 Matcher m=p.matcher(name);
		 if(m.matches()) {
			 return true;
		 }
		return false;
	}
	/*public boolean validateBalance(Double amount) throws AccountException {
		String temp=Double.toString(amount);
		if(Pattern.matches("[0-9]{1,9}", temp))
		{
			 return true;
		 }
		return false;
	}*/
	public boolean validateContact(String contact) throws AccountException {
		if(Pattern.matches("[789]{1}[0-9]{9}", contact))
		{
			 return true;
		 }
		return false;
	}
	public boolean validateAccouuntType(String acType) throws AccountException {
		if(acType.equals("saving") || acType.equals("current"))
		{
			 return true;
		 }
		return false;
	}

}
