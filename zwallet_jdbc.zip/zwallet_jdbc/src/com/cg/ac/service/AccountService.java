package com.cg.ac.service;

import java.sql.SQLException;
import java.util.HashMap;
import com.cg.ac.bean.Account;
import com.cg.ac.exception.AccountException;

public interface AccountService {
	public String createAccount(Account account)throws AccountException, ClassNotFoundException, SQLException;
	public Account showBalance(String accountNo)throws AccountException;
	
	public boolean validateName(String name) throws AccountException;
	

}
