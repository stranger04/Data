package com.cg.ac.dao;

import java.sql.SQLException;
import java.util.HashMap;
import com.cg.ac.bean.Account;
import com.cg.ac.exception.AccountException;


public interface AccountDao {
	public String createAccount(Account account)throws  ClassNotFoundException, SQLException;
	public Account showBalance(String accountNo)throws AccountException;
	
	
	

}
