package com.cg.ac.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.ac.Util.JDBC;
import com.cg.ac.bean.Account;
import com.cg.ac.exception.AccountException;
 
public class AccountDaoImpl implements AccountDao {
	

	@Override
	public String createAccount(Account account) throws ClassNotFoundException, SQLException  {
		Connection c=JDBC.connect();
		Statement stmt=c.createStatement();
		PreparedStatement pst =  c.prepareStatement("INSERT INTO ACCOUNT VALUES(?,?,?,?,?)");
		pst.setInt(1,account.getAccountNo());
		pst.setString(2, account.getName());
		pst.setDouble(3, account.getBalance());
		pst.setString(4, account.getContactNo());
		pst.setString(5, account.getAccountType());
		pst.executeUpdate();
		return null;
		
	}

	@Override
	public Account showBalance(String accountNo) throws AccountException {
		// TODO Auto-generated method stub
		return null;
	}

}