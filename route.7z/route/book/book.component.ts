import { Component, OnInit } from '@angular/core';
import { BookService } from '../book.service';
import { IBook } from './book';

@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})
export class BookComponent implements OnInit {
  books:IBook[];
  isUpdate:boolean=false;
  id:number;
  title:string;
  year:number;
  author:string;

  constructor(private service:BookService) { }

  ngOnInit() {
    this.service.getBooks().subscribe(data=>this.books=data);
  }
  update(book:IBook)
  {
    this.id=book.id;
    this.title=book.title;
    this.year=book.year;
    this.author=book.author;
    this.isUpdate=true;
  }
delete(book:IBook)
{
  let arr=this.books.filter(p=>p.id!=book.id);
  this.books=arr;
}
  updateDetail()
  {
    let arr=this.books.filter(p=>p.id !=this.id);
    arr.push({id:this.id,title:this.title,year:this.year,author:this.author});
    this.books=arr;
    this.isUpdate=false;

  }

}
