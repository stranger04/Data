package com.cg.day2;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class Author {
private String authorname;
private String address;

public Author(String authorname, String address) {
	super();
	this.authorname = authorname;
	this.address = address;
}
public String getAuthorname() {
	return authorname;
}
public void setAuthorname(String authorname) {
	this.authorname = authorname;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
@Override
public String toString() {
	return "Author [authorname=" + authorname + ", address=" + address + "]";
}

@PostConstruct
public void customAuthorInit()
{
	System.out.println("Method customAuthorInit() invoked");
}

@PreDestroy
public void customAuthorDestroy()

{
	System.out.println("Method customAuthorDestroy() invoked.");
	
}


}
