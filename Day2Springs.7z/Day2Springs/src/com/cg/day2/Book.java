package com.cg.day2;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class Book {
private String ISBN;
private String Year;
private Author author;
public String getISBN() {
	return ISBN;
}
public void setISBN(String iSBN) {
	ISBN = iSBN;
}
public String getYear() {
	return Year;
}
public void setYear(String year) {
	Year = year;
}
public Author getAuthor() {
	return author;
}
public void setAuthor(Author author) {
	this.author = author;
}
@Override
public String toString() {
	return "Book [ISBN=" + ISBN + ", Year=" + Year + ", author=" + author + "]";
}


@PostConstruct
public void customBookInit()
{
	System.out.println("Method customBookInit() invoked");
}

@PreDestroy
public void customBookDestroy()

{
	System.out.println("Method customBookDestroy() invoked.");
	
}


public void setUp() throws Exception
{
	System.out.println("Initializing the Book Bean with custom Config");
}
public void cleanUp() throws Exception
{
	System.out.println("Destroying the Book Bean with custom Config");
}
}
