package com.cg.day2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class BookClient {
public static void main(String[] args) {
	ApplicationContext ctx=new AnnotationConfigApplicationContext(MyBookConfig.class);
	Book book1=(Book) ctx.getBean("book");
	System.out.println(book1);
}
}
