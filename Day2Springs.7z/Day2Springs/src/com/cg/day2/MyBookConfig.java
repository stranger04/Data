package com.cg.day2;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MyBookConfig {
	@Bean
	public Author author()
	{
		Author author=new Author("Shiva","Bangalore");
		return author;
	}
	@Bean(initMethod="setUp",destroyMethod="cleanUp")
	public Book book()
	{
		Book book=new Book();
		book.setISBN("1234");
		book.setYear("1998");
		book.setAuthor(author());
		return book;
		
	}

}
