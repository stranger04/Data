package com.cg.exception;

public class CusException extends Exception{

	public CusException() {
		super("error");
		// TODO Auto-generated constructor stub
	}

}
