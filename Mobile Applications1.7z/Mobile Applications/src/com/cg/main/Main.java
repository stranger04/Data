package com.cg.main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

import com.cg.bean.Customer;
import com.cg.bean.Mobile;
import com.cg.exception.CusException;
import com.cg.service.Service;
import com.cg.service.Serviceimpl;
import com.cg.util.Util;



public class Main {
	static Scanner sc=null;
	static Service mobservice=null; 
	public static void main(String[] args) throws CusException {
		sc=new Scanner(System.in);
		mobservice=new Serviceimpl();
		int choice=0;
		while(true)
		{
			System.out.println("Task to be performed....");
			System.out.println("1.Add mobile details");
			System.out.println("2.Add customer details");
			System.out.println("3.Remove mobile details");
			System.out.println("4.Remove customer details");
			System.out.println("5.sorting");
			System.out.println("6.fetch");
			System.out.println("Enter the choice:");
			choice=sc.nextInt();
			switch (choice){
			case 1:	
				addmobiledetails();
				break;
			case 2:	
				addcustomerdetails();
				break;
			case 3:	
				removemobile();
				break;
			case 4:	
				removecustomer();
				break;
			case 5:	
				sorting();
				sorting1();
				sorting2();
				break;
			case 6:
				fetch();
				break;
				default:
					System.out.println("no choice:");
				break;
			}
		}
}
	private static void addmobiledetails() {
		// TODO Auto-generated method stub
		{
			Random r=new Random();
			int mobileorderid=r.nextInt();
			System.out.println("Enter price:");
			float pricewithgst=sc.nextFloat();
			System.out.println("Enter Mobile model:");
			String model=sc.next();
		   	Mobile md=new Mobile(mobileorderid, pricewithgst, model);
						mobservice.addmobiledetails(mobileorderid, md);
						System.out.println("Mobiledetails added"+md);
						}
				}
	private static void addcustomerdetails() throws CusException  {
		// TODO Auto-generated method stub
		{
			System.out.println("enter your name:");
			String name=sc.next();
			boolean result = mobservice.validatename(name) ;
			
			if(result==true)
			{
			
			System.out.println("Enter your mobile number:");
			String no=sc.next();
			boolean result1 = mobservice.validatenum(no) ;
			if(result1==true)
			{ 
				System.out.println("Enter address:");
				String addr=sc.next();
				Customer e=new Customer(name, addr, no);
				mobservice.addcustomerdetails(e);
				System.out.println("Customerdetails added"+e);
			}
			else
			{
				throw new CusException();
			}
			}
			else
			{
					throw new CusException();
			}
	}
	}
	private static void removemobile()
	{
		System.out.println("enter the mobile id:");
		int mobileorderid=sc.nextInt();
		HashMap<Integer, Mobile> h=mobservice.removemobile(mobileorderid);
System.out.println(h);
	}
	
	private static void removecustomer()
	{
		System.out.println("enter the mobile no:");
		int mobile=sc.nextInt();
		HashMap<String, Customer> h=mobservice.removecustomer(mobile);
System.out.println(h);
			
	}
	private static void sorting()
	{
ArrayList<Mobile> a=mobservice.sorting();
System.out.println("\nSorted by id"); 
for (int i=0; i<a.size(); i++) 
    System.out.println(a.get(i));
		
	}
	private static void sorting1()
	{
ArrayList<Mobile> a=mobservice.sorting1();
System.out.println("\nSorted by model");
for (int i=0; i<a.size(); i++) 
    System.out.println(a.get(i));
		
	}
	private static void sorting2()
	{
ArrayList<Mobile> a=mobservice.sorting2();
System.out.println("\nSorted by price");
for (int i=0; i<a.size(); i++) 
    System.out.println(a.get(i));
		
	}
	private static void fetch()
	{
		Map<String,Customer> l= mobservice.display();
		 Set set = ((Map) l).entrySet();
	     Iterator iterator = set.iterator();
	     while(iterator.hasNext()) {
	        Map.Entry e = (Map.Entry)iterator.next();
	        System.out.print( e.getKey() +"   " );
	        System.out.println(e.getValue());
	     }
	    
	}
}
