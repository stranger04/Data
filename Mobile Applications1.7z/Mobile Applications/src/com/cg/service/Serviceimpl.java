package com.cg.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.bean.Customer;
import com.cg.bean.Mobile;
import com.cg.dao.DAO;
import com.cg.dao.DAOimpl;
import com.cg.exception.CusException;

public class Serviceimpl implements Service {
DAO d=new DAOimpl();
	@Override
	public HashMap<Integer, Mobile> addmobiledetails(int o, Mobile md) {
		// TODO Auto-generated method stub
		return d.addmobiledetails(o, md);
	}

	@Override
	public HashMap<String, Customer> addcustomerdetails(Customer c) throws CusException {
		// TODO Auto-generated method stub
		return d.addcustomerdetails(c);
	}

	@Override
	public HashMap<Integer, Mobile> removemobile(int id) {
		// TODO Auto-generated method stub
		return d.removemobile(id);
	}

	@Override
	public HashMap<String, Customer>  removecustomer(int mobileno) {
		// TODO Auto-generated method stub
		return d.removecustomer(mobileno);
	}
	public boolean validatename(String name)
	{
	Pattern p=Pattern.compile("[A-Z]{1}[a-z]{3,16}");
	Matcher nameMatch=p.matcher(name);
	if(nameMatch.matches())
	{
		return true;
	}
	return false;
	}
	public boolean validatenum(String mobileno)
	{
	Pattern p=Pattern.compile("[0-9]{10}");
	Matcher mobilenoMatch=p.matcher(mobileno);
	if(mobilenoMatch.matches())
	{
		return true;
	}
	return false;
	}

	@Override
	public ArrayList<Mobile> sorting() {
		// TODO Auto-generated method stub
		return d.sorting();
	}
	@Override
	public ArrayList<Mobile> sorting1() {
		// TODO Auto-generated method stub
		return d.sorting1();
	}
	@Override
	public ArrayList<Mobile> sorting2() {
		// TODO Auto-generated method stub
		return d.sorting2();
	}

	@Override
	public Map<String, Customer> display() {
		// TODO Auto-generated method stub
		return d.display();
	}

}
