package com.cg.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.cg.bean.Customer;
import com.cg.bean.Mobile;
import com.cg.exception.CusException;



public interface Service {

	public HashMap<Integer, Mobile> addmobiledetails(int o,Mobile md);
	public HashMap<String, Customer> addcustomerdetails(Customer c) throws CusException;
	public HashMap<Integer, Mobile> removemobile(int id);
	public HashMap<String, Customer>  removecustomer(int mobileno);
	public ArrayList<Mobile> sorting();
	public ArrayList<Mobile> sorting1();
	public ArrayList<Mobile> sorting2();
	public boolean validatenum(String no);
	public boolean validatename(String name);
	public Map<String, Customer> display();
}
