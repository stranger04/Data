package com.cg.bean;

import java.util.Comparator;

public class Sorting1 implements Comparator<Mobile>{
	
	@Override
	
public int compare(Mobile m1, Mobile m2) 
{ 
    return m1.getModel().compareTo(m2.getModel()); 
} 
}
