package com.cg.bean;

import java.util.Comparator;

public class Sorting2 implements Comparator<Mobile>{

	@Override
	public int compare(Mobile o1, Mobile o2) {
		// TODO Auto-generated method stub
		return (int) (o1.pricewithgst-o2.getPricewithgst());
	}

	

}
