package com.cg.bean;

import java.util.Comparator;

public class Sorting implements Comparator<Mobile>{

	@Override
	public int compare(Mobile o1, Mobile o2) {
		// TODO Auto-generated method stub
		return o1.mobileorderid-o2.mobileorderid;
	}
	
}
