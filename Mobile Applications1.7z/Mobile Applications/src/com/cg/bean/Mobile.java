package com.cg.bean;

import java.util.Comparator;

public class Mobile{
	int mobileorderid;
	float pricewithgst;
	String model;
	public Mobile(int mobileorderid, float pricewithgst, String model) {
		super();
		this.mobileorderid = mobileorderid;
		this.pricewithgst = pricewithgst;
		this.model = model;
	}
	public int getMobileorderid() {
		return mobileorderid;
	}
	public void setMobileorderid(int mobileorderid) {
		this.mobileorderid = mobileorderid;
	}
	public float getPricewithgst() {
		return pricewithgst;
	}
	public void setPricewithgst(float pricewithgst) {
		this.pricewithgst = pricewithgst;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	@Override
	public String toString() {
		return "Mobile [mobileorderid=" + mobileorderid + ", pricewithgst=" + pricewithgst + ", model=" + model + "]";
	}
	   
}
