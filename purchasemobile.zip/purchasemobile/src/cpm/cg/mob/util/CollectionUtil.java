package cpm.cg.mob.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.mob.entity.Customer;
import com.cg.mob.entity.Mobile;

public class CollectionUtil {
	public static HashMap<Integer,Customer>cus=new HashMap<Integer,Customer>();
	static
	{
		cus.put(12313,new Customer("krishna","hyderabad","8886477538"));
		cus.put(12313,new Customer("raushan","patna","8886477234"));
		cus.put(12313,new Customer("chetanp","Banglore","8886477231"));
		cus.put(12313,new Customer("sahithk","hyderabad","8886477537"));
	}
	public static void addCus(Customer cust) {
		cus.put(null,cust);
	}
	public static HashMap<String,Mobile>mob=new HashMap<String,Mobile>();
	static
	{
		mob.put("Sony",new Mobile("Aoek123","1342dd",12345));
		mob.put("Nokia",new Mobile("Aoqk123","1122dd",12345));
		mob.put("Samsung",new Mobile("Afsk123","1142dd",12345));
		mob.put("Apple",new Mobile("Asak123","1562dd",12345));
		
	}
	public static HashMap<String,Mobile>fetchAllMobileDetails()
	{
		return mob;
	}
	public static Mobile getMobilebyBrand(String mobile) {
		Mobile mobi=mob.get(mobile);
		return mobi;
	}
	

}
