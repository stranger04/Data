package com.cg.mob.entity;

public class Mobile {
	private String mobileOrderId;
	private String customerId;
	private double totalPrice;
	public Mobile(String mobileOrderId, String customerId, double totalPrice) {
		super();
		this.mobileOrderId = mobileOrderId;
		this.customerId = customerId;
		this.totalPrice = totalPrice;
	}
	public Mobile() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getMobileOrderId() {
		return mobileOrderId;
	}
	public void setMobileOrderId(String mobileOrderId) {
		this.mobileOrderId = mobileOrderId;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	@Override
	public String toString() {
		return "Mobile [mobileOrderId=" + mobileOrderId + ", customerId=" + customerId + ", totalPrice=" + totalPrice
				+ "]";
	}
	

}
