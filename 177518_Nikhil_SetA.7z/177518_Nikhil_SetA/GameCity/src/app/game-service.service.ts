import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { observable, Observable } from 'rxjs';
import { IGames } from './play/Games';
@Injectable({
  providedIn: 'root'
})
export class GameServiceService {
  url1 : string = "assets/GameList.json";
  constructor(private http: HttpClient) { }

  getGames() : Observable<IGames []>
  {
    return this.http.get<IGames []>(this.url1);
  }
}
