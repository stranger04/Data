import { Component, OnInit } from '@angular/core';
import { IGames } from '../play/Games';
import { FormGroup, Validators, FormControl } from '@angular/forms';

@Component({
  selector: 'app-game-city',
  templateUrl: './game-city.component.html',
  styleUrls: ['./game-city.component.css']
})
export class GameCityComponent implements OnInit {
  games: IGames[];
  userForm: FormGroup;

  constructor() { }

  ngOnInit() {
    this.userForm=new FormGroup({
     Name:new FormControl('',[Validators.required,Validators.minLength(20)]),
      Address:new FormControl('',[Validators.required,Validators.minLength(20)]),
      Amount:new FormControl(null,[Validators.required,Validators.pattern("^[0-9]{4}$")]),
    });
  }

}
