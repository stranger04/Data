import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Route,RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';

import { PlayComponent } from './play/play.component';
import { GameCityComponent } from './game-city/game-city.component';


const routes : Route [] = [
  {
path : 'gamecity',
component : GameCityComponent
  },
  {
    path: 'play',
    component:PlayComponent
  }];

@NgModule({
  declarations: [
    AppComponent,
  
    PlayComponent,
    GameCityComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(routes),
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
