export interface IGames
{
    gameId : number ;
    gameName : string ;
    gamePrice : number ;
   
    Name: String ;
    Address : string ;
     Amount : number ;
    
}