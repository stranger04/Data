import { Component, OnInit } from '@angular/core';
import { IGames } from './Games';
import { GameServiceService } from '../game-service.service';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-play',
  templateUrl: './play.component.html',
  styleUrls: ['./play.component.css']
})
export class PlayComponent implements OnInit {
  games : IGames [] ;

  gameId : number ;
  gameName : string ;
  gamePrice : number;

  balance:number=600;
  servicecharge:number=100;

  constructor(private service : GameServiceService, private http:HttpClient) { }

  ngOnInit() {
    this.service.getGames().subscribe(data=>this.games=data);
  }
 
  PlayNow(games:IGames)
  {
    this.balance=(this.balance-games.gamePrice);
    alert("your remaining balance is"+ this.balance)
    let arr= this.games.filter(p => p. gameId  != games. gameId );
    this.games=arr;
   
  }

}
