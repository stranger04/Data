package com.cg.ac.bean;


public class Customer {

	private String name;
	private String panNo;
	private String aadharNo;
	private String accountNo;
	private String contact;
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(String name, String panNo, String aadharNo, String accountNo, String contact) {
		super();
		this.name = name;
		this.panNo = panNo;
		this.aadharNo = aadharNo;
		this.accountNo = accountNo;
		this.contact = contact;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPanNo() {
		return panNo;
	}
	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}
	public String getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	@Override
	public String toString() {
		return "Customer [name=" + name + ", panNo=" + panNo + ", aadharNo=" + aadharNo + ", accountNo=" + accountNo
				+ ", contact=" + contact + "]";
	}
	
	

}
