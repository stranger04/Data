package com.cg.ac.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.cg.ac.bean.Account;
import com.cg.ac.bean.Customer;
import com.cg.ac.exception.AccountException;

public class AccountDaoImp implements AccountDao {
	static Account account=null;
	static Connection con=null;
	static PreparedStatement pstmt= null;
	static ResultSet result=null;
	static String sql;
	
	static{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","India123" );
			con.setAutoCommit(false);
			System.out.println("Welcome to wallet services\n");
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		}
	
	@Override
	public String createAccount(Account account,Customer customer) throws AccountException {
		try {
		
		sql="INSERT INTO AccountDetails VALUES(?,?,?,?,?)";
		pstmt= con.prepareStatement(sql);
		
		pstmt.setString(1, account.getAccountNo());
		pstmt.setString(2, account.getName());
		pstmt.setDouble(3, account.getBalance());
		pstmt.setString(4, account.getContactNo());
		pstmt.setString(5, account.getAccountType());
		pstmt.executeUpdate();
		
		sql="INSERT INTO CustomerDetails VALUES(?,?,?,?,?)";
		pstmt= con.prepareStatement(sql);
		
		pstmt.setString(1, customer.getAccountNo());
		pstmt.setString(2, customer.getName());
		pstmt.setString(3, customer.getPanNo());
		pstmt.setString(4, customer.getAadharNo());
		pstmt.setString(5, customer.getContact());
		pstmt.executeUpdate();
		
		System.out.println("AccountNo:"+account.getAccountNo()+" created succesfully!!");
		con.commit();
		} 
		catch (SQLException e) {
			
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Account showBalance(String accountNo) throws AccountException {
		
		try {
			sql="SELECT *FROM ACCOUNTDETAILS WHERE ACCOUNTNUMBER =?";
			pstmt= con.prepareStatement(sql);
			pstmt.setString(1, accountNo); 
			result=pstmt.executeQuery();
			
			if (!result.isBeforeFirst() ) {    
			    System.out.println("User doesn't exist."); 
			} else {
				while (result.next()) {
					/*account.setBalance(result.getDouble(3));
					System.out.println(account.getBalance());*/
					System.out.println("Account No: "+result.getString(1)+", Balance: "+result.getDouble(3));
				}
				
			}
			
			con.commit();
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Account deposite(String accountNo, double amount) throws AccountException {
		
		try {
			sql="UPDATE  ACCOUNTDETAILS SET BALANCE =(BALANCE + ?) WHERE ACCOUNTNUMBER =?";
			pstmt= con.prepareStatement(sql);
			pstmt.setDouble(1, amount); 
			pstmt.setString(2, accountNo); 
			result=pstmt.executeQuery();
			
			if (result.next() ) {    
			    System.out.println("Amount deposited: "+amount ); 
			} else {
				System.out.println("User doesn't exist.");
					
				}
			
			con.commit();
			
		} catch (Exception e) {
			System.out.println("User doesn't exist.");
			
		}
		return null;
	}

	@Override
	public Account withDraw(String accountNo, double amount) throws AccountException {

		try {
			sql=" UPDATE  ACCOUNTDETAILS SET BALANCE =(BALANCE - ?) WHERE ACCOUNTNUMBER =?";
			pstmt= con.prepareStatement(sql);
			pstmt.setDouble(1, amount); 
			pstmt.setString(2, accountNo); 
			result= pstmt.executeQuery();
			if (result.next() ) {    
			    System.out.println("Amount withdrawn: "+amount ); 
			} else {
				System.out.println("User doesn't exist.");
					
				}
			con.commit();
			
		} catch (Exception e) {
			System.out.println("User doesn't exist.");
		}
		return null;
		
	}

	@Override
	public Account fundTransfer(String accountNo, String accountNo1, double amount) throws AccountException {
		try {
		sql=" UPDATE  ACCOUNTDETAILS SET BALANCE =(BALANCE - ?) WHERE ACCOUNTNUMBER =?";
		
		
		pstmt= con.prepareStatement(sql);
		pstmt.setDouble(1, amount); 
		pstmt.setString(2, accountNo); 
		pstmt.executeQuery();
		sql="UPDATE  ACCOUNTDETAILS SET BALANCE =(BALANCE + ?) WHERE ACCOUNTNUMBER =?";
		pstmt= con.prepareStatement(sql);
		pstmt.setDouble(1, amount); 
		pstmt.setString(2, accountNo1); 
		pstmt.executeQuery();
		if (result.next() ) {    
		    System.out.println("Transaction successful.\n" ); 
		} else {
			System.out.println("User doesn't exist.");
				
			}
		con.commit();
		
		} catch (Exception e) {
			System.out.println("User doesn't exist.");
		}
		return null;
	}

}
