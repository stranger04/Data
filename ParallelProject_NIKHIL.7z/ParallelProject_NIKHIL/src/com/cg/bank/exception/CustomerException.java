package com.cg.bank.exception;

public class CustomerException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CustomerException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	
}
