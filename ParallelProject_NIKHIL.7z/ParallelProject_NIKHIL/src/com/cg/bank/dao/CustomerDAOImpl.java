package com.cg.bank.dao;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.util.CollectionUtil;

public class CustomerDAOImpl implements CustomerDAO {

	@Override
	public int createAccount(Customer c, Account a) {
		
		return CollectionUtil.createAccount(c, a);
	}

	@Override
	public double showBalance(int accountNo) {
		
		return CollectionUtil.showBalance(accountNo);
	}

	@Override
	public double deposit(double amount, int accountNo) {
		
		return CollectionUtil.deposit(amount, accountNo);
	}

	@Override
	public double withdraw(double amount, int accounNo) {
		
		return CollectionUtil.withdraw(amount, accounNo);
	}

	@Override
	public boolean fundTransfer(double amount,int accountNo1,
			int accountNo2) {
				return CollectionUtil.fundTransfer(amount, accountNo1, accountNo2);
		
	}

	@Override
	public Account printTransaction(int accountno) {
		return CollectionUtil.printTransaction(accountno);
		
	}

}
