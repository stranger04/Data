package com.cg.bank.util;

import java.util.HashMap;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;

public class CollectionUtil {
public static HashMap<Integer, Customer> hm = new HashMap<>();
	
	static 
	{
		hm.put(1001, new Customer(1001,"Nikhil","7205558258","Bellary"));
		hm.put(1002, new Customer(1002,"Shiva","8760815735","Banglore"));
		hm.put(1003, new Customer(1003,"Shantu","9876549876","Gadag"));
		hm.put(1004, new Customer(1004,"Chetan","7894567894","Hubli"));

	}
	
	public static HashMap<Integer, Account> am = new HashMap<>();
	
	static
	{
		am.put(1001, new Account (1001,1,"Bellary","NSSC121",25000));
		am.put(1002, new Account (1002,1,"Bellary","NSSC121",24000));
		am.put(1003, new Account (1003,2,"Bellary","NSSC121",23000));
		am.put(1004, new Account (1004,2,"Bellary","NSSC121",22000));
	
	}

	
	public static int createAccount(Customer c,Account a)
	{
		hm.put(c.getAccountNo(), c);
		am.put(a.getAccountNumber(), a);
		return a.getAccountNumber();
		
	}
    public static double showBalance(int accountNo)
    {
    	
    	if(hm.containsKey(accountNo))
    	{
    		Account ac=am.get(accountNo);
    	   return ac.getBalance();
    	}
    	else
    	{
    		return 0;
    	}
    }
    public static double deposit(double amount,int accountno)
    {
    	double acc2=0;
    		Account ac=am.get(accountno);
    		double acc=ac.getBalance();
    		acc2=amount+acc;
    		ac.setBalance(acc2);
    		am.put(accountno, ac);
    		return acc2;
    	
    }
    public static double withdraw(double amount,int accounNo)
    {
    	double acc2=0;
    	Account ac=am.get(accounNo);
    	double acc=ac.getBalance();
    		if(amount<=(acc-500))
    	{
    		acc2=acc-amount;
    		ac.setBalance(acc2);
    		am.put(accounNo, ac);
    		return acc2;
    }
    		else
    		{
    		return 0;	
    		}
    		
    	}
    public static boolean fundTransfer(double amount,Integer accountno,Integer accountno1)
    {
    	double acc2=0;
    	double acc4=0;
    	Account ac=am.get(accountno);
    	Account a=am.get(accountno1);
    	double acc=ac.getBalance();
    	double acc3=ac.getBalance();
    		if(amount<=(acc-500))
    	{
    		acc2=acc-amount;
    		ac.setBalance(acc2);
    		am.put(accountno, ac);
    	    acc4=acc3+amount;
    	    a.setBalance(acc4);
    	    am.put(accountno1, a);
    		return true;
    }
    		else
		return false;
    	
    }
    	public static Account printTransaction(int accountno)
    	{
			return am.get(accountno);
    		
    	}
    	
}
