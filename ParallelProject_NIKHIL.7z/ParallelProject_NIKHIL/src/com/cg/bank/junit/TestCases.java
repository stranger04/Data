package com.cg.bank.junit;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.bank.dao.CustomerDAO;
import com.cg.bank.dao.CustomerDAOImpl;
import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.exception.CustomerException;

public class TestCases {

	static CustomerDAO cusdao=null; 
	@BeforeClass
		public static void setUp()
		{
			cusdao=new CustomerDAOImpl();
		} 
	@Test
	public void createAccountTest() {
		Assert.assertEquals(1111, cusdao.createAccount(new Customer(1001, "Nikhil", "7205558258", "Bellary"), new Account(1111,1,"Bangalore","IFSC1234",25000)));
	}

/*	@Test
	public void testShowBalance() throws CustomerException {
		Assert.assertEquals(15000,cusdao.showBalance(1001));
	}
	
	@Test
	public void testDeposit() throws CustomerException{
		Assert.assertEquals(18000, cusdao.deposit(1234567890, 0)+3000);
	}
	
	@Test
	public void testWithdraw() throws CustomerException{
		Assert.assertEquals(13000, cusdao.deposit(1234567890, 0)-2000);
	}
	
	@Test
	public void testFundTransfer() throws CustomerException{
		Assert.assertEquals(13000, cusdao.deposit(1234567890, 0)-2000);
		Assert.assertEquals(30000,cusdao.fundTransfer(25000,1001, 1));
	}*/
	
	
}
