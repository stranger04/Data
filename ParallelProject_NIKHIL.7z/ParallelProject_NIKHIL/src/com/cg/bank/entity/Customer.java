package com.cg.bank.entity;

public class Customer {

	
	int accountNo;
	String customerName;
	String customerMobileNo;
	String customerAddress;
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(int accountNo, String customerName,
			String customerMobileNo, String customerAddress) {
		super();
		this.accountNo = accountNo;
		this.customerName = customerName;
		this.customerMobileNo = customerMobileNo;
		this.customerAddress = customerAddress;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerMobileNo() {
		return customerMobileNo;
	}
	public void setCustomerMobileNo(String customerMobileNo) {
		this.customerMobileNo = customerMobileNo;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	@Override
	public String toString() {
		return "Customer [accountNo=" + accountNo + ", customerName="
				+ customerName + ", customerMobileNo=" + customerMobileNo
				+ ", customerAddress=" + customerAddress + "]";
	}
	
}
