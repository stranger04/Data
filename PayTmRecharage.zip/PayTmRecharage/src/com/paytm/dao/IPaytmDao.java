package com.paytm.dao;

import com.paytm.bean.Paytm;

public interface IPaytmDao {
  
	 
	 
	public abstract void viewById(int id);
	public abstract void deleteById(int id);
    public abstract int Addtransaction(Paytm r);
	public abstract void viewAllTransactions();
	public abstract boolean updateDescription(int id, String description);
	
}
