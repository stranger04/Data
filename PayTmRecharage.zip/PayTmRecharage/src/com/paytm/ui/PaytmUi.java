package com.paytm.ui;


import java.util.Scanner;

import com.paytm.bean.Paytm;
import com.paytm.service.IPaytmService;
import com.paytm.service.PaytmServiceImpl;




 

public class PaytmUi  {
static Scanner scan=new Scanner(System.in);
   static IPaytmService irs=null;
   
	public static void main(String[] args) {
		 System.out.println("Enter a choice b/w 1-5");
		 System.out.println("Enter 1.add transaction");
		 System.out.println(" 2.view All Transactions\n 3.view by Tid");
		 System.out.println("4.update Description \n 5.delete Transaction");
		 int a=scan.nextInt();
		do {
			switch(a) {
		 case 1: int tid=addtr();
		 System.out.println("Recharge successfully");
			System.out.println("Transaction  ID is:"+tid);
		 
			 break;
		 case 2:
			     viewAllTransactions();
			     
			 break;
		 case 3:
			 
			 viewById();
			 break;
		 case 4:
			 System.out.println("Enter tID  update description");
			 int id=scan.nextInt();
			 update(id);
			 break;
		 case 5:
			 System.out.println("Enter tID delete transaction");
			 int did=scan.nextInt();
			 delete(did);
			 break;
		 }
			System.out.println("Enter yes to continuee ....or no to exit");
			if(scan.next().equalsIgnoreCase("yes")) {
				System.out.println("enter choice");
				a=scan.nextInt();
			}
			else {	
			a=6;
			}
			
	}while(a<6);
	}
	private static void delete(int did) {
		System.out.println("Enter the Id for delete");
		did=scan.nextInt();
		irs=new PaytmServiceImpl() ;
		irs.deleteById(did);
		
	}
	private static void update(int tid) {
		irs=new PaytmServiceImpl() ;
		System.out.println("Enter description for update");
		String description=scan.next();
		irs.updateDescription(tid, description);
		
	}
	private static void viewById() {
		 
		System.out.println("Enter ID ");
	      int id1=scan.nextInt();
		irs=new PaytmServiceImpl() ;
		irs.viewById(id1);
	}
	private static void viewAllTransactions() {
		IPaytmService rssl=null;
		 rssl=new PaytmServiceImpl();
		 rssl.viewAllTransactions();
		
	}
	private static int addtr() {
		String name=null;
		String rechargeType=null;
		String description=null;
		String planName=null;
		int rcId=0;
		int amount=0;
		String mobNum=null;
		int balance=0;
		String date=null;
		boolean validate=false;
		IPaytmService irs=null;
		irs=new PaytmServiceImpl();
		do{
            try{
				System.out.println("Enter the name");
				name=scan.next();
				validate=irs.validateName(name);
            }
            catch(Exception ne){
	    		System.out.println("Invalid Name");
	    	}
			}while(validate==false);
		do{
            try{
				System.out.println("Enter the Mobile number");
				mobNum=scan.next();
				validate=irs.validateMobileNum(mobNum);
            }
            catch(Exception ne){
	    		System.out.println("Invalid MobileNo");
	    	}
			}while(validate==false);
		do {
            try {
            	System.out.println("Enter amount");
	            amount=scan.nextInt();
	            validate=irs.validateAmount(amount);
            }
             catch(Exception e)	{
            	 System.out.println("Invalid Amount");
             }
            }while(validate==false);
			try{
				System.out.println("Enter the rechargetype 1.for Prepaid\n 2.Postpaid");
			int b=scan.nextInt();
			switch(b) {
			case 1:rechargeType="Prepaid";
			System.out.println("Enter your planning");
			System.out.println("1.RC10\n2.RC100\n 3.Rc299 4.Rc499 ");
			int rc=scan.nextInt();
			 
			switch(rc) {
			case 1: System.out.println("Recharge 10 rupees successfully");
			planName="Rc10";
			description="10 rupees talktime for 7 days";
			balance=amount-10;
				break;
			case 2:
				System.out.println("RERecharge 100 rupees successfully");
				planName="Rc100";
				description="unlimited talktime for 28 days";
				balance=amount-100;
				break;
			case 3:
				System.out.println("Recharge 299 rupees successfully");
				planName="Rc299";
				description="unlimited talktime, 1.4Gb per day and 100 sms per day till 28days";
				balance=amount-299;
				break;
			case 4:
				System.out.println("Recharge 499 rs successfully");
				planName="Rc499";
				description="unlimited talktime, 1.4Gb per day and 100 sms per day till 72days";
				balance=amount-499;
				break;
			 
			
			}
			break;
			case 2:rechargeType="Postpaid";
			System.out.println("Enter your choice for planning");
			System.out.println("1.RC599\n2.RC999 ");
			int rc1=scan.nextInt();
			switch(rc1) {
			case 1: System.out.println("Recharge 599 rupees successfully");
			planName="Rc599";
			description="599 rupees talktime for 7 days";
			balance=amount-599;
				break;
			case 2:
				System.out.println("Recharge 999 rupees successfully");
				planName="Rc999";
				description="unlimited talktime for 28 days";
				balance=amount-999;
				break;}
			
			default:
				System.out.println("Invalid type");
			}
				
				validate=irs.validateRechargeType(rechargeType);
			}
			catch(Exception ne){
	    		System.out.println("Invalid Recharge ");
	    	}
	            
			try{
				System.out.println("Enter date");
				date=scan.next();
			}
			catch(Exception ne){
	    		System.out.println("Invalid DOJ");
	    	}
			
			 
			
			Paytm r=new Paytm	(name,rechargeType,description,planName,amount,mobNum,balance,date); 
	    int id=irs.Addtransaction(r);
		return id;
	}

}
