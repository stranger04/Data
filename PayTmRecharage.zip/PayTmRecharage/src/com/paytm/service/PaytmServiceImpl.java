package com.paytm.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.paytm.bean.Paytm;
import com.paytm.dao.IPaytmDao;
import com.paytm.dao.PaytmDaoImpl;
import com.paytm.exception.PaytmException;

 

public class PaytmServiceImpl implements IPaytmService {
	IPaytmDao ird=null;

	public PaytmServiceImpl(String name, String rechargeType, String description, String planName, int amount,
			String mobNum, int balance, String date) {
		// TODO Auto-generated constructor stub
	}
	public PaytmServiceImpl() {
		// TODO Auto-generated constructor stub
	}
	 
	public int generateTid(){
		int id;
		id=(int)(Math.random()*10000);
		
		return id;
	}


	@Override
	public boolean validateMobileNum(String mobNum) throws PaytmException{
		
		Pattern p=Pattern.compile("^[6-9][0-9]{8}");
		Matcher m=p.matcher(mobNum);
		if (m.find()){
			return true;
		}
		
			else{
				 throw new PaytmException("num  error");
			 }
		}
	

	@Override
	public boolean validateRechargeType(String rechargeType)throws PaytmException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateAmount(int amount) throws PaytmException{
		boolean b=false;
		if (amount>3000){
			b= true;
		}
		else{
			 throw new PaytmException("Amount error");
		 }
		return b;
	}

	@Override
	public boolean validateName(String name)throws PaytmException {
		Pattern p=Pattern.compile("^[A-Z]([a-z]){3,}");
		Matcher m=p.matcher(name);
		boolean b=false;
		 if(m.find()){  
			b=true;
		 }
		 else{
			 
			 throw new PaytmException("Name error");
			}
		 return b;
	}

	 
	@Override
	public int Addtransaction(Paytm r) { 
		r.setRcId( generateTid());
		ird=new PaytmDaoImpl();
		return ird.Addtransaction(r);
	}
	@Override
	public void viewAllTransactions() {
		ird=new PaytmDaoImpl();
		  ird.viewAllTransactions();
		
	}
	@Override
	public void viewById(int id) {
		ird=new PaytmDaoImpl();
		  ird. viewById(id);
		
	}
	@Override
	public void deleteById(int id) {
		ird=new PaytmDaoImpl();
		 ird.deleteById(id);
		
	}
	@Override
	public boolean updateDescription(int id, String description) {
		ird=new PaytmDaoImpl();
		return ird.updateDescription(id, description);
	}

 
}
