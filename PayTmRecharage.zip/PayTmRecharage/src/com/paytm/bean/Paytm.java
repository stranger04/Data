package com.paytm.bean;

import java.time.LocalDate;

public class Paytm {
	String name;
	String RechargeType;
	String description;
	String planName;
	int rcId;
	int amount;
	String mobileNum;
	int balance;
	String date;
	public Paytm() {
		// TODO Auto-generated constructor stub
	}
	public Paytm(String name, String rechargeType, String description, String planName, int rcId, int amount,
			String mobileNum, int balance,String date) {
		super();
		this.name = name;
		RechargeType = rechargeType;
		this.description = description;
		this.planName = planName;
		this.rcId = rcId;
		this.amount = amount;
		this.mobileNum = mobileNum;
		this.balance = balance;
		this.date = date;
	}
	public Paytm(String name, String rechargeType, String description, String planName, int amount,
			String mobileNum, int balance,String date) {
		super();
		this.name = name;
		RechargeType = rechargeType;
		this.description = description;
		this.planName = planName;
		this.amount = amount;
		this.mobileNum = mobileNum;
		this.balance = balance;
		this.date = date;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRechargeType() {
		return RechargeType;
	}
	public void setRechargeType(String rechargeType) {
		RechargeType = rechargeType;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public int getRcId() { 
		
		return rcId;
	}
	public void setRcId(int rcId) {
		this.rcId = rcId;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getMobileNum() {
		return mobileNum;
	}
	public void setMobileNum(String mobileNum) {
		this.mobileNum = mobileNum;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	}
