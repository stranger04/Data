import { Component, OnInit } from '@angular/core';
import { IBook } from './book';
import { BookService } from '../book.service';
import { FormGroup, FormControlName, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-bookform',
  templateUrl: './bookform.component.html',
  styleUrls: ['./bookform.component.css']
})
export class BookformComponent implements OnInit {
  userForm:FormGroup;
  book:IBook[];
  
  

  constructor(private service:BookService) { }

  ngOnInit() {
    this.userForm= new FormGroup(
      {
        id:new FormControl('',[Validators.required,Validators.pattern("^[0-9]$")]),
        title: new FormControl('',[Validators.required, Validators.minLength(6)]),
        year:new FormControl('',[Validators.required, Validators.pattern("^[0-9]{4}$")]),
        author:new FormControl('',[Validators.required])
      }
    );
    this.service.getBooks().subscribe(data=>this.book=data);
  }
  onSubmit(obj:any)
  {
    
    let arr=this.book.filter(p => p.id == obj.id);
    if(arr.length>0)
    {
      alert("id already exist");
    }
    else{
      this.book.push({id:obj.id, title:obj.title, year:obj.year, author:obj.author});
    }
  
    
   
  }
  
}
