import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { EmployeeComponent } from './employee/employee.component';
import { DepartmentComponent } from './department/department.component';
import { Route,RouterModule } from '@angular/router';
import { EmployeedetailComponent } from './employeedetail/employeedetail.component';
import { BookComponent } from './book/book.component';
import { HttpClientModule } from '@angular/common/http';
import { UserComponent } from './user/user.component';
import { BookformComponent } from './bookform/bookform.component';

const routes : Route [] = [
  {
path : 'bookform',
component : BookformComponent
  },
  {
    path: 'user',
    component:UserComponent
  },
  {
    path : 'book' ,
    component : BookComponent
  },
  {
    path : 'empdetail/:id',
    component : EmployeedetailComponent
  },
  {
  path : 'emp' ,
  component : EmployeeComponent
},
{
  path:'dept',
  component:DepartmentComponent
},
{
  path: '',
  redirectTo:'/emp',
  pathMatch : 'full'
},
{
  path:"**",
  component:EmployeeComponent
}];

@NgModule({
  declarations: [
    AppComponent,
    EmployeeComponent,
    DepartmentComponent,
    EmployeedetailComponent,
    BookComponent,
    UserComponent,
    BookformComponent
  ],
  imports: [
    BrowserModule,
FormsModule,
RouterModule.forRoot(routes),
HttpClientModule,
ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
