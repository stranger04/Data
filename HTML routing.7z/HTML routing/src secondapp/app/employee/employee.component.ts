import { Component, OnInit, Input } from '@angular/core';
import { Employee } from './employee';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
doj= new Date();
  imageUrl="../assets/download (1).jpg"
  @Input('name')title : string;
  employees: Employee [] = [
    {employeeId:1001,employeeName:'Antony',employeeSalary:89000},
    {employeeId:1002,employeeName:'Steve',employeeSalary:65000},
    {employeeId:1003,employeeName:'Bruce',employeeSalary:80000}

  ];

/* eid: number;
ename: string;
esal: number; */
  constructor() { }

  ngOnInit() {
  }
  add(eid,ename,esal)
  {
    this.employees.push({employeeId: eid, employeeName:ename,employeeSalary:esal});
  }
sortById(){
this.employees.sort((p1,p2)=>p1.employeeId-p2.employeeId);
}
sortByName(){
this.employees.sort((p1,p2)=>p1.employeeName.localeCompare(p2.employeeName));
}
sortBySalary(){
  this.employees.sort((p1,p2)=>p1.employeeSalary-p2.employeeSalary);
}

search()
{
  let arr=this.employees.filter(p=>p.employeeId==this.eid);
if(arr.length>0)
{
  this.eid=arr[0].employeeId;
  this.ename=arr[0].employeeName;
  this.esal=arr[0].employeeSalary;
}
}
}
