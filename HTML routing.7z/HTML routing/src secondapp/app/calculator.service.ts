import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CalculatorService {

  constructor() { }

  addition(a,b) : number 
  {
  let c= parseInt(a) + parseInt(b);
    return c;
  }
  multiplication(a,b) : number 
  {
let c=a*b;
return c;
  }
}
