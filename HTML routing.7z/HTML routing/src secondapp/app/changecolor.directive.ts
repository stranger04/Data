import { Directive, ElementRef, Renderer, HostListener, HostBinding } from '@angular/core';
import { BrowserDomAdapter } from '@angular/platform-browser/src/browser/browser_adapter';

@Directive({
  selector: '[appChangecolor]'
})
export class ChangecolorDirective {
@HostBinding('style.border')BrowserDomAdapter:string;
  border: string;
  background: string;

  constructor(private el:ElementRef, private renderer: Renderer) 
  {
    this.el.nativeElement.setElementStyle(this.el.nativeElement, 'color','red');
   }
@HostListener('mouseover') onMouseover()
{
  this.renderer.setElementStyle(this.el.nativeElement, 'color', 'yellow');
  this.border="2px solid gray";
  this.background="magenta";
}
@HostListener('mouseout') onMouseout()
{
  this.renderer.setElementStyle(this.el.nativeElement, 'color', 'blue');
  this.border='2px solid green'
}
}
