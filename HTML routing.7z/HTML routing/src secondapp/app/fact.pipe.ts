import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'fact'
})
export class FactPipe implements PipeTransform {

  transform(value: any, args?: any): any {
  /*   let n:number,fact:number; */
 let fact=1;
 for(let i=1;i<=value;i++)
 {
   fact*=i;
 }
 return fact;
}
 }
