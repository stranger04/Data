import { Component, OnInit } from '@angular/core';
import { CalculatorService } from '../calculator.service';

@Component({
  selector: 'app-calculator',
  templateUrl: './calculator.component.html',
  styleUrls: ['./calculator.component.css']
})
export class CalculatorComponent implements OnInit {
  result: any;

  constructor(private service : CalculatorService) { }
  ngOnInit() {
  }
  add(a:number,b:number)
  {
 this.result=this.service.addition(a,b);
}
mul(a:number,b:number)
{
  this.result=this.service.multiplication(a,b);
}
}