import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'First angular project';
  employeeId:number=1001;
  employeeName:string='Antony';
  employeeaddress :string ;
  phone=['121-121-121','2323-2323-2323','34343-3434-3434'];
  message="Hide phone";
  className="header";
  status = true;
Hide()
{
  /* console.log('show method called'); */
/*   this.status=false; */
this.status=!this.status;
}
show()
{
this.status=!this.status;
this.message = status ? 'hide phone': 'show phone';
}
}
