import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  products =
   [ { pid : 1001, pname : 'Mobile',price:5000},
  {pid : 1002,pname : 'watch',price : 900},
  {pid : 1003,pname : 'Laptop',price : 70000},
];
searchProduct : any [] ;
  pid: any;
  constructor() { 
this.searchProduct = this.products;

  }
find()
{
  this.searchProduct=this.products.filter(p=>p.pid==this.pid);
console.log('find called');
}
  ngOnInit() {
  }

}
